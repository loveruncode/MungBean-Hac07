/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 327:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src_App)
});

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__(885);
// EXTERNAL MODULE: ./node_modules/@expo/vector-icons/build/MaterialCommunityIcons.js + 2 modules
var MaterialCommunityIcons = __webpack_require__(5202);
// EXTERNAL MODULE: ./node_modules/@expo/vector-icons/build/MaterialIcons.js + 2 modules
var MaterialIcons = __webpack_require__(3770);
// EXTERNAL MODULE: ./node_modules/@expo-google-fonts/dev/index.js + 1 modules
var dev = __webpack_require__(1708);
// EXTERNAL MODULE: ./node_modules/@react-navigation/bottom-tabs/lib/module/navigators/createBottomTabNavigator.js + 16 modules
var createBottomTabNavigator = __webpack_require__(9245);
// EXTERNAL MODULE: ./node_modules/@react-navigation/native/lib/module/NavigationContainer.js + 7 modules
var NavigationContainer = __webpack_require__(5693);
// EXTERNAL MODULE: ./node_modules/@react-navigation/stack/lib/module/navigators/createStackNavigator.js + 30 modules
var createStackNavigator = __webpack_require__(1866);
// EXTERNAL MODULE: ./node_modules/buffer/index.js
var buffer = __webpack_require__(2486);
// EXTERNAL MODULE: ./node_modules/expo/build/launch/registerRootComponent.js + 5 modules
var registerRootComponent = __webpack_require__(5813);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(9526);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/ActivityIndicator/index.js
var ActivityIndicator = __webpack_require__(6032);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/View/index.js
var View = __webpack_require__(1133);
// EXTERNAL MODULE: ./node_modules/recoil/es/index.js
var es = __webpack_require__(7672);
;// CONCATENATED MODULE: ./src/constants/Colors.ts
var Colors={dark:{background:'#121212',text:'#fff',inputBackground:'#1E1E1E',innerBackground:'#282832',greyText:'#949494',purple:'#6C5DD3',red:'#C96183'}};
;// CONCATENATED MODULE: ./src/constants/Fonts.ts
var BOLD='DMSans-Bold';var MEDIUM='DMSans-Medium';var REGULAR='DMSans-Regular';
;// CONCATENATED MODULE: ./src/constants/index.ts

// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/StyleSheet/index.js + 6 modules
var StyleSheet = __webpack_require__(4333);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Text/index.js
var Text = __webpack_require__(9233);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Image/index.js + 2 modules
var Image = __webpack_require__(9899);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__(4942);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(5861);
// EXTERNAL MODULE: ./node_modules/@react-native-async-storage/async-storage/lib/module/index.js + 3 modules
var lib_module = __webpack_require__(5519);
// EXTERNAL MODULE: ./node_modules/@shyft-to/js/dist/esm/index.js + 24 modules
var esm = __webpack_require__(1882);
;// CONCATENATED MODULE: ./src/constants/Banker.ts
var bankerAddress='EbGWwCXS4YqRp2Kq7cYPuFmJsboPwJv4KeoyrV3cW45m';var privateWalKey='294eRqVT43v6FEFzQs39xRQ3VvN9tqi5pxPfZj4eRPfwWUnyFGaUCr8C3yTxUmkuRtBGdpAxKx4mcFZR2XhQfRKd';
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 40 modules
var axios = __webpack_require__(8615);
;// CONCATENATED MODULE: ./src/services/api.service.ts
var api=axios["default"].create();api.interceptors.response.use(function(res){return res.data;});var ApiService={post:function post(url,data){var config=arguments.length>2&&arguments[2]!==undefined?arguments[2]:{};return api.post(url,data,config);},get:function get(url){return api.get(url);}};
// EXTERNAL MODULE: ./node_modules/@solana/web3.js/lib/index.browser.esm.js + 7 modules
var index_browser_esm = __webpack_require__(6969);
;// CONCATENATED MODULE: ./src/services/shyft.service.ts
/* provided dependency */ var Buffer = __webpack_require__(2486)["Buffer"];
var apiKey='Uc6QK72WsU6HXlwM';var shyft=new esm.ShyftSdk({apiKey:apiKey,network:esm.Network.Devnet});var marketplaceAddress='DUR7FnsaK5fN93qygYAgA9YDrc8mwjM9AspdAvCXLSec';var ShyftService={sendSol:function(){var _sendSol=(0,asyncToGenerator["default"])(function*(address,amount){var body={network:esm.Network.Devnet,from_address:address,to_address:bankerAddress,amount:Number(amount)};var response=ApiService.post('https://api.shyft.to/sol/v1/wallet/send_sol',body,{headers:{'x-api-key':apiKey}});return response;});function sendSol(_x,_x2){return _sendSol.apply(this,arguments);}return sendSol;}(),withdraw:function(){var _withdraw=(0,asyncToGenerator["default"])(function*(address,amount){var body={network:esm.Network.Devnet,from_address:bankerAddress,to_address:address,amount:Number(amount)};var response=ApiService.post('https://api.shyft.to/sol/v1/wallet/send_sol',body,{headers:{'x-api-key':apiKey}});return response;});function withdraw(_x3,_x4){return _withdraw.apply(this,arguments);}return withdraw;}(),getBalance:function(){var _getBalance=(0,asyncToGenerator["default"])(function*(wallet){var response=yield shyft.wallet.getBalance({wallet:wallet});return response.toFixed(2);});function getBalance(_x5){return _getBalance.apply(this,arguments);}return getBalance;}(),getProfile:function(){var _getProfile=(0,asyncToGenerator["default"])(function*(wallet){var response=yield shyft.wallet.getPortfolio({wallet:wallet});return response.nfts;});function getProfile(_x6){return _getProfile.apply(this,arguments);}return getProfile;}(),signContract:function(){var _signContract=(0,asyncToGenerator["default"])(function*(encodedTransaction,wallet){var network="devnet";var rpcUrl=(0,index_browser_esm.clusterApiUrl)(network);var connection=new index_browser_esm.Connection(rpcUrl,"confirmed");var recoveredTransaction=index_browser_esm.Transaction.from(Buffer.from(encodedTransaction,"base64"));var signedTx=yield wallet.signTransaction(recoveredTransaction);var confirmTransaction=yield connection.sendRawTransaction(signedTx.serialize());return confirmTransaction;});function signContract(_x7,_x8){return _signContract.apply(this,arguments);}return signContract;}(),signWithPrivate:function(){var _signWithPrivate=(0,asyncToGenerator["default"])(function*(encodedTransaction){var network=esm.Network.Devnet;var privateKeys=[privateWalKey];return yield (0,esm.signAndSendTransactionWithPrivateKeys)(network,encodedTransaction,privateKeys);});function signWithPrivate(_x9){return _signWithPrivate.apply(this,arguments);}return signWithPrivate;}(),getActiveListings:function(){var _getActiveListings=(0,asyncToGenerator["default"])(function*(){var size=arguments.length>0&&arguments[0]!==undefined?arguments[0]:6;var page=arguments.length>1&&arguments[1]!==undefined?arguments[1]:1;return yield shyft.marketplace.listing.active({network:esm.Network.Devnet,marketplaceAddress:marketplaceAddress,sortBy:"price",sortOrder:"desc",page:page,size:size});});function getActiveListings(){return _getActiveListings.apply(this,arguments);}return getActiveListings;}(),buyNFT:function(){var _buyNFT=(0,asyncToGenerator["default"])(function*(_ref){var nftAddress=_ref.nftAddress,sellerWallet=_ref.sellerWallet,buyerWallet=_ref.buyerWallet,price=_ref.price;return yield shyft.marketplace.listing.buy({marketplaceAddress:marketplaceAddress,price:price,nftAddress:nftAddress,sellerWallet:sellerWallet,buyerWallet:buyerWallet});});function buyNFT(_x10){return _buyNFT.apply(this,arguments);}return buyNFT;}(),listing:function(){var _listing=(0,asyncToGenerator["default"])(function*(_ref2){var nftAddress=_ref2.nftAddress,price=_ref2.price,sellerWallet=_ref2.sellerWallet;return yield shyft.marketplace.listing.list({marketplaceAddress:marketplaceAddress,nftAddress:nftAddress,price:price,sellerWallet:sellerWallet});});function listing(_x11){return _listing.apply(this,arguments);}return listing;}()};
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(7557);
;// CONCATENATED MODULE: ./src/context/WalletContext.tsx
function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);enumerableOnly&&(symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;})),keys.push.apply(keys,symbols);}return keys;}function _objectSpread(target){for(var i=1;i<arguments.length;i++){var source=null!=arguments[i]?arguments[i]:{};i%2?ownKeys(Object(source),!0).forEach(function(key){(0,defineProperty["default"])(target,key,source[key]);}):Object.getOwnPropertyDescriptors?Object.defineProperties(target,Object.getOwnPropertyDescriptors(source)):ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}return target;}var WalletContext=(0,react.createContext)({wallet:null,setWallet:function setWallet(){},refresh:function refresh(){}});var WalletProvider=function WalletProvider(_ref){var children=_ref.children;var _useState=(0,react.useState)(null),_useState2=(0,slicedToArray["default"])(_useState,2),wallet=_useState2[0],setWallet=_useState2[1];var refresh=function(){var _ref2=(0,asyncToGenerator["default"])(function*(amount){if(wallet&&wallet.address){var balance=yield ShyftService.getBalance(wallet.address);var appBalance=yield lib_module["default"].getItem('appBalance');console.log(Number(balance)+amount);setWallet(function(prev){return _objectSpread(_objectSpread({},prev),{},{balance:(Number(balance)+Number(amount)).toFixed(2),appBalance:appBalance});});}});return function refresh(_x){return _ref2.apply(this,arguments);};}();(0,react.useEffect)(function(){var fetchWalletAddress=function(){var _ref3=(0,asyncToGenerator["default"])(function*(){try{var address=yield lib_module["default"].getItem('walletAddress');if(address){setWallet({address:address,balance:0});}}catch(error){console.log('Error fetching wallet address:',error);}});return function fetchWalletAddress(){return _ref3.apply(this,arguments);};}();fetchWalletAddress();},[]);return (0,jsx_runtime.jsx)(WalletContext.Provider,{value:{wallet:wallet,setWallet:setWallet,refresh:refresh},children:children});};/* harmony default export */ const context_WalletContext = (WalletProvider);
;// CONCATENATED MODULE: ./src/components/Balance.tsx
function Balance(){var _useContext=(0,react.useContext)(WalletContext),wallet=_useContext.wallet;return (0,jsx_runtime.jsx)(View["default"],{style:styles.container,children:(0,jsx_runtime.jsxs)(View["default"],{style:{flexDirection:'column',gap:4},children:[(0,jsx_runtime.jsxs)(View["default"],{style:styles.row,children:[(0,jsx_runtime.jsx)(View["default"],{style:{paddingRight:10,paddingLeft:4},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:styles.text,children:"Wallet :"})}),(0,jsx_runtime.jsx)(View["default"],{children:(0,jsx_runtime.jsx)(Image["default"],{style:{width:20,height:20,resizeMode:'cover'},source:__webpack_require__(363)})}),(0,jsx_runtime.jsx)(View["default"],{style:{paddingRight:10,paddingLeft:4},children:(0,jsx_runtime.jsxs)(Text["default"],{allowFontScaling:false,style:{fontSize:13,color:Colors.dark.text,textAlign:'right',fontFamily:REGULAR,width:70},children:[wallet&&wallet.balance||'0.00'," SOL"]})})]}),(0,jsx_runtime.jsxs)(View["default"],{style:styles.row,children:[(0,jsx_runtime.jsx)(View["default"],{style:{paddingRight:10,paddingLeft:4},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:styles.text,children:"App :"})}),(0,jsx_runtime.jsx)(View["default"],{children:(0,jsx_runtime.jsx)(Image["default"],{style:{width:20,height:20,resizeMode:'cover'},source:__webpack_require__(363)})}),(0,jsx_runtime.jsx)(View["default"],{style:{paddingRight:10,paddingLeft:4},children:(0,jsx_runtime.jsxs)(Text["default"],{allowFontScaling:false,style:{fontSize:13,color:Colors.dark.text,textAlign:'right',fontFamily:REGULAR,width:70},children:[wallet&&wallet.appBalance||'0.00'," SOL"]})})]})]})});}var styles=StyleSheet["default"].create({container:{display:'flex',position:'relative',justifyContent:'flex-end',alignItems:'center',flexDirection:'row',backgroundColor:Colors.dark.inputBackground,minHeight:50,maxWidth:'100vw'},row:{justifyContent:'center',alignItems:'center',flexDirection:'row'},text:{fontSize:13,color:Colors.dark.text,textAlign:'right',fontFamily:REGULAR,width:50}});
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/ScrollView/index.js + 2 modules
var ScrollView = __webpack_require__(8576);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Dimensions/index.js
var Dimensions = __webpack_require__(6337);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/TouchableOpacity/index.js
var TouchableOpacity = __webpack_require__(1451);
;// CONCATENATED MODULE: ./src/components/Menu/Menu.tsx
var Menu=function Menu(_ref){var navigation=_ref.navigation;var _useContext=(0,react.useContext)(WalletContext),wallet=_useContext.wallet;var screenWidth=Dimensions["default"].get('window').width;var innerSizeFontSizePercentage=0.025;var headerSizeFontSizePercentage=0.035;var innerSize=screenWidth*innerSizeFontSizePercentage||'14px';var headerSize=screenWidth*headerSizeFontSizePercentage||'14px';return (0,jsx_runtime.jsxs)(ScrollView["default"],{style:Menu_styles.container,showsHorizontalScrollIndicator:false,children:[(0,jsx_runtime.jsxs)(View["default"],{style:Menu_styles.appWrapper,children:[(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Menu_styles.innerApp,Menu_styles.searching],onPress:function onPress(){return navigation.navigate('Search');},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:{fontSize:innerSize,color:Colors.dark.text,textAlign:'center',fontFamily:REGULAR},children:"Search Inventory"})}),(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Menu_styles.innerApp,Menu_styles.marketplace],onPress:function onPress(){return navigation.navigate('Marketplace');},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:{fontSize:innerSize,color:Colors.dark.text,textAlign:'center',fontFamily:REGULAR},children:"Marketplace"})})]}),(0,jsx_runtime.jsxs)(View["default"],{style:[Menu_styles.appWrapper,{marginTop:10}],children:[(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Menu_styles.innerApp,{backgroundColor:'#A91079'}],onPress:function onPress(){return navigation.navigate('Deposit Withdraw');},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:{fontSize:innerSize,color:Colors.dark.text,textAlign:'center',fontFamily:REGULAR},children:"Deposit / Withdraw"})}),(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Menu_styles.innerApp,{backgroundColor:'#570A57'}],onPress:function onPress(){return navigation.navigate('Transfer');},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:{fontSize:innerSize,color:Colors.dark.text,textAlign:'center',fontFamily:REGULAR},children:"Transfer"})})]}),(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:{fontSize:headerSize,color:Colors.dark.text,textAlign:'left',fontFamily:REGULAR,fontWeight:'700',paddingVertical:20},children:"Game"}),(0,jsx_runtime.jsxs)(View["default"],{style:Menu_styles.appWrapper,children:[(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Menu_styles.innerApp,{backgroundColor:'#570A57'}],onPress:function onPress(){return navigation.navigate('Lucky Game');},children:(0,jsx_runtime.jsx)(Text["default"],{allowFontScaling:false,style:{fontSize:innerSize,color:Colors.dark.text,textAlign:'center',fontFamily:REGULAR},children:"Lucky Game"})}),(0,jsx_runtime.jsx)(View["default"],{style:Menu_styles.innerApp}),(0,jsx_runtime.jsx)(View["default"],{style:Menu_styles.innerApp}),(0,jsx_runtime.jsx)(View["default"],{style:Menu_styles.innerApp})]})]});};var Menu_styles=StyleSheet["default"].create({container:{paddingHorizontal:6,paddingVertical:12},appWrapper:{display:'flex',flexDirection:'row',gap:20,alignItems:'center',flexGrow:1,width:'100%',flexWrap:'wrap'},innerApp:{display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'center',flexGrow:0.8,height:'20vh',width:'15%',padding:13,backgroundColor:Colors.dark.inputBackground,borderRadius:8,cursor:'pointer'},searching:{backgroundColor:'#66347F'},marketplace:{backgroundColor:'#9E4784'}});
;// CONCATENATED MODULE: ./src/components/Screen.tsx
function Screen(_ref){var style=_ref.style,children=_ref.children;return (0,jsx_runtime.jsx)(View["default"],{style:[Screen_styles.screen,style],children:children});}var Screen_styles=StyleSheet["default"].create({screen:{flex:1,paddingBottom:0}});
;// CONCATENATED MODULE: ./src/screens/AppMenu.tsx
var AppMenu=function AppMenu(_ref){var navigation=_ref.navigation;return (0,jsx_runtime.jsxs)(Screen,{style:AppMenu_styles.container,children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsx)(Menu,{navigation:navigation})]});};var AppMenu_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background}});
;// CONCATENATED MODULE: ./src/App.css
// extracted by mini-css-extract-plugin
/* harmony default export */ const App = ({});
// EXTERNAL MODULE: ./node_modules/@solana/spl-token/lib/esm/state/mint.js + 22 modules
var state_mint = __webpack_require__(3898);
;// CONCATENATED MODULE: ./src/utils/components.tsx
function FullScreenLoadingIndicator(_ref){var variantBackground=_ref.variantBackground;return (0,jsx_runtime.jsx)(View["default"],{style:{position:'absolute',top:0,left:0,right:0,bottom:0,zIndex:999,flex:1,alignItems:'center',justifyContent:'center',backgroundColor:variantBackground?Colors.dark.innerBackground:Colors.dark.background},children:(0,jsx_runtime.jsx)(ActivityIndicator["default"],{color:"#eee"})});}var HeaderLeft=function HeaderLeft(_ref2){var title=_ref2.title;return (0,jsx_runtime.jsx)("div",{style:{display:'flex',justifyContent:'center',alignItems:'center',height:55,marginLeft:10},children:(0,jsx_runtime.jsx)(Text["default"],{style:{color:Colors.dark.text,fontSize:20,paddingLeft:5,fontFamily:BOLD},children:title})});};var ItemSeparatorComponent=function ItemSeparatorComponent(){return (0,jsx_runtime.jsx)(View["default"],{style:{marginVertical:8,borderColor:Colors.dark.inputBackground,borderBottomWidth:1}});};
;// CONCATENATED MODULE: ./src/utils/index.ts
function getTokenAccount(_x,_x2){return _getTokenAccount.apply(this,arguments);}function _getTokenAccount(){_getTokenAccount=(0,asyncToGenerator["default"])(function*(owner,mint){return yield (0,state_mint.getAssociatedTokenAddress)(mint,owner,true);});return _getTokenAccount.apply(this,arguments);}function humanFileSize(bytes){var si=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;var dp=arguments.length>2&&arguments[2]!==undefined?arguments[2]:1;var thresh=si?1000:1024;if(Math.abs(bytes)<thresh){return bytes+' B';}var units=si?['kB','MB','GB','TB','PB','EB','ZB','YB']:['KiB','MiB','GiB','TiB','PiB','EiB','ZiB','YiB'];var u=-1;var r=10**dp;do{bytes/=thresh;++u;}while(Math.round(Math.abs(bytes)*r)/r>=thresh&&u<units.length-1);return bytes.toFixed(dp)+' '+units[u];}function byteSizeUnited(n){return n<1024?'1KB':n<1048576?(n/1024).toFixed(0)+'KB':n<1073741824?(n/1048576).toFixed(0)+'MB':(n/1073741824).toFixed(0)+'GB';}function sortFileInfoArray(files,input){return files.sort(function(a,b){var aName=a.name.toLowerCase();var bName=b.name.toLowerCase();var inputName=input.toLowerCase();if(aName.includes(inputName)&&!bName.includes(inputName)){return-1;}else if(!aName.includes(inputName)&&bName.includes(inputName)){return 1;}else{return aName.localeCompare(bName);}});}function shortenString(key){var firstFour=key.substr(0,4);var lastFour=key.substr(-4);return firstFour+"..."+lastFour;}
;// CONCATENATED MODULE: ./src/context/LoadingContext.tsx
var LoadingContext=(0,react.createContext)({loading:false,setLoading:function setLoading(){}});var LoadingProvider=function LoadingProvider(_ref){var children=_ref.children;var _useState=(0,react.useState)(false),_useState2=(0,slicedToArray["default"])(_useState,2),loading=_useState2[0],setLoading=_useState2[1];return (0,jsx_runtime.jsx)(LoadingContext.Provider,{value:{loading:loading,setLoading:setLoading},children:children});};/* harmony default export */ const context_LoadingContext = (LoadingProvider);
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-react/lib/esm/ConnectionProvider.js
var ConnectionProvider = __webpack_require__(322);
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-react/lib/esm/WalletProvider.js + 24 modules
var esm_WalletProvider = __webpack_require__(5648);
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-base/lib/esm/types.js
var types = __webpack_require__(6863);
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-unsafe-burner/lib/esm/adapter.js + 3 modules
var adapter = __webpack_require__(9196);
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-react-ui/lib/esm/WalletModalProvider.js + 4 modules
var WalletModalProvider = __webpack_require__(610);
;// CONCATENATED MODULE: ./src/context/AdapterWallet.tsx
function Wallet(_ref){var children=_ref.children;var network=types.WalletAdapterNetwork.Devnet;var endpoint=(0,react.useMemo)(function(){return (0,index_browser_esm.clusterApiUrl)(network);},[network]);var wallets=(0,react.useMemo)(function(){return[new adapter.UnsafeBurnerWalletAdapter()];},[network]);return (0,jsx_runtime.jsx)(ConnectionProvider.ConnectionProvider,{endpoint:endpoint,children:(0,jsx_runtime.jsx)(esm_WalletProvider.WalletProvider,{wallets:wallets,autoConnect:true,children:(0,jsx_runtime.jsx)(WalletModalProvider.WalletModalProvider,{children:children})})});};
;// CONCATENATED MODULE: ./src/context/ProviderWrapper.tsx
function ProviderWrapper(_ref){var children=_ref.children;return (0,jsx_runtime.jsx)(context_LoadingContext,{children:(0,jsx_runtime.jsx)(Wallet,{children:(0,jsx_runtime.jsx)(context_WalletContext,{children:children})})});}
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Button/index.js
var Button = __webpack_require__(1553);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Platform/index.js
var Platform = __webpack_require__(7132);
;// CONCATENATED MODULE: ./src/services/nft.service.ts
var NFTService={getInfo:function(){var _getInfo=(0,asyncToGenerator["default"])(function*(url){var response=yield ApiService.get(url);return response;});function getInfo(_x){return _getInfo.apply(this,arguments);}return getInfo;}()};
// EXTERNAL MODULE: ./node_modules/@react-navigation/core/lib/module/index.js + 62 modules
var core_lib_module = __webpack_require__(2727);
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Modal/index.js + 4 modules
var Modal = __webpack_require__(196);
;// CONCATENATED MODULE: ./src/components/ModalPopup/ModalPopup.tsx
function ModalPopup(_ref){var isVisible=_ref.isVisible,closeModal=_ref.closeModal,title=_ref.title,children=_ref.children;return (0,jsx_runtime.jsx)(Modal["default"],{animationType:"slide",transparent:true,visible:isVisible,onRequestClose:closeModal,children:(0,jsx_runtime.jsx)(View["default"],{style:ModalPopup_styles.modalContainer,children:(0,jsx_runtime.jsxs)(View["default"],{style:ModalPopup_styles.modalContent,children:[(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:ModalPopup_styles.closeModal,onPress:closeModal,children:(0,jsx_runtime.jsx)(Text["default"],{style:{fontFamily:BOLD,fontSize:24},children:"X"})}),(0,jsx_runtime.jsx)(Text["default"],{style:{fontFamily:BOLD,fontSize:24,marginBottom:20},children:title}),children]})})});};var ModalPopup_styles=StyleSheet["default"].create({container:{flex:1,justifyContent:'center',alignItems:'center'},modalContainer:{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'rgba(0, 0, 0, 0.1)'},modalContent:{backgroundColor:'white',padding:20,borderRadius:8,elevation:5,width:'80%'},closeModal:{position:'absolute',right:10,top:4}});
;// CONCATENATED MODULE: ./src/components/Card/ItemCard.tsx
function ItemCard_ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);enumerableOnly&&(symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;})),keys.push.apply(keys,symbols);}return keys;}function ItemCard_objectSpread(target){for(var i=1;i<arguments.length;i++){var source=null!=arguments[i]?arguments[i]:{};i%2?ItemCard_ownKeys(Object(source),!0).forEach(function(key){(0,defineProperty["default"])(target,key,source[key]);}):Object.getOwnPropertyDescriptors?Object.defineProperties(target,Object.getOwnPropertyDescriptors(source)):ItemCard_ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}return target;}function ItemCard(_ref){var _item$nft2,_item$content3,_item$content3$metada,_item$nft3;var item=_ref.item,handleListing=_ref.handleListing;var _useState=(0,react.useState)(null),_useState2=(0,slicedToArray["default"])(_useState,2),info=_useState2[0],setInfo=_useState2[1];var _useState3=(0,react.useState)(''),_useState4=(0,slicedToArray["default"])(_useState3,2),price=_useState4[0],setPrice=_useState4[1];var _useState5=(0,react.useState)(false),_useState6=(0,slicedToArray["default"])(_useState5,2),showPopup=_useState6[0],setShowPopup=_useState6[1];var route=(0,core_lib_module.useRoute)();(0,react.useEffect)(function(){(0,asyncToGenerator["default"])(function*(){var _item$content,_item$content$files,_item$nft;if(!(item!=null&&(_item$content=item.content)!=null&&(_item$content$files=_item$content.files)!=null&&_item$content$files.length)&&!(item!=null&&(_item$nft=item.nft)!=null&&_item$nft.image_uri)){var _info=yield NFTService.getInfo(item.uri);console.log(_info);setInfo(_info);}else{var _item$content2;setInfo((_item$content2=item.content)==null?void 0:_item$content2.files[0]);}})();},[]);var handleShowPopUp=function handleShowPopUp(type){return setShowPopup(type);};return (0,jsx_runtime.jsxs)(View["default"],{style:ItemCard_styles.cardWrapper,children:[(0,jsx_runtime.jsx)(Image["default"],{source:(info==null?void 0:info.uri)||(info==null?void 0:info.image)||(item==null?void 0:(_item$nft2=item.nft)==null?void 0:_item$nft2.image_uri),style:ItemCard_styles.image}),(0,jsx_runtime.jsxs)(View["default"],{style:route.name==='Marketplace'&&ItemCard_styles.marketBottomCard,children:[(0,jsx_runtime.jsx)(Text["default"],{style:{color:Colors.dark.text,fontSize:14,fontFamily:BOLD,textAlign:'center'},children:(item==null?void 0:(_item$content3=item.content)==null?void 0:(_item$content3$metada=_item$content3.metadata)==null?void 0:_item$content3$metada.name)||(item==null?void 0:(_item$nft3=item.nft)==null?void 0:_item$nft3.name)||(info==null?void 0:info.name)}),(item==null?void 0:item.price)&&(0,jsx_runtime.jsxs)(View["default"],{style:{alignItems:'center',flexDirection:'row'},children:[(0,jsx_runtime.jsx)(Text["default"],{style:{color:Colors.dark.text,fontSize:14,fontFamily:BOLD},children:item==null?void 0:item.price}),(0,jsx_runtime.jsx)(Text["default"],{style:{color:'#9548FC',fontSize:14,fontFamily:BOLD,marginLeft:4},children:item==null?void 0:item.currency_symbol})]}),route.name==='Profile'&&(0,jsx_runtime.jsxs)(jsx_runtime.Fragment,{children:[(0,jsx_runtime.jsx)(View["default"],{style:{marginTop:10},children:(0,jsx_runtime.jsx)(Button["default"],{onPress:function onPress(){return handleShowPopUp(true);},title:"Listing"})}),(0,jsx_runtime.jsxs)(ModalPopup,{title:'List NFT',isVisible:showPopup,closeModal:function closeModal(){return handleShowPopUp(false);},children:[(0,jsx_runtime.jsxs)(View["default"],{style:ItemCard_styles.listItem,children:[(0,jsx_runtime.jsx)("label",{style:ItemCard_styles.listingLabel,children:"Price"}),(0,jsx_runtime.jsx)("input",{style:ItemCard_styles.listingInput,value:price,onChange:function onChange(e){return setPrice(e.currentTarget.value);}})]}),(0,jsx_runtime.jsxs)(View["default"],{style:ItemCard_styles.listItem,children:[(0,jsx_runtime.jsx)("label",{style:ItemCard_styles.listingLabel,children:"NFT Address"}),(0,jsx_runtime.jsx)("input",{style:ItemCard_styles.listingInput,value:item.address,disabled:true})]}),(0,jsx_runtime.jsx)(Button["default"],{onPress:function onPress(){return handleListing(ItemCard_objectSpread(ItemCard_objectSpread({},item),{},{price:price}));},title:"Listing"})]})]})]})]});}var isMobile=Platform["default"].OS==='ios'||Platform["default"].OS==='android';var ItemCard_styles=StyleSheet["default"].create({container:{flex:1,flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},cardWrapper:{width:'40vw',height:'45vh',backgroundColor:Colors.dark.inputBackground,borderRadius:8,borderWidth:2,borderColor:Colors.dark.text,padding:10,marginVertical:10,alignItems:'center'},image:{width:'100%',height:'80%',resizeMode:'cover',borderTopLeftRadius:12,borderTopRightRadius:12},marketBottomCard:{marginTop:10,width:'100%',flexDirection:'row',justifyContent:'space-between'},listItem:{display:'flex',flexDirection:'row',gap:10,marginBottom:20},listingLabel:{fontFamily:MEDIUM,fontSize:18,width:120},listingInput:{flex:1}});
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js
var useWallet = __webpack_require__(9105);
;// CONCATENATED MODULE: ./src/components/Profile/ProfileComponent.tsx
var ProfileComponent=function ProfileComponent(_ref){var navigation=_ref.navigation;var _useContext=(0,react.useContext)(WalletContext),walletInfo=_useContext.wallet;var _useWallet=(0,useWallet.useWallet)(),wallet=_useWallet.wallet;var _useState=(0,react.useState)(null),_useState2=(0,slicedToArray["default"])(_useState,2),userProfile=_useState2[0],setUserProfile=_useState2[1];var _useContext2=(0,react.useContext)(LoadingContext),loading=_useContext2.loading,setLoading=_useContext2.setLoading;var route=(0,core_lib_module.useRoute)();var _handleListing=function(){var _ref2=(0,asyncToGenerator["default"])(function*(item){try{var _walletInfo$address;console.log(walletInfo);var _yield$ShyftService$l=yield ShyftService.listing({nftAddress:item.address,price:item.price,sallerWallet:walletInfo==null?void 0:(_walletInfo$address=walletInfo.address)==null?void 0:_walletInfo$address.publicKey}),encoded_transaction=_yield$ShyftService$l.encoded_transaction;if(encoded_transaction){yield ShyftService.signContract(encoded_transaction,wallet);}}catch(e){console.log(e);}});return function handleListing(_x){return _ref2.apply(this,arguments);};}();(0,react.useEffect)(function(){setLoading(true);(0,asyncToGenerator["default"])(function*(){if(walletInfo!=null&&walletInfo.address){var _userProfile=yield ShyftService.getProfile(walletInfo.address);setUserProfile(_userProfile);setLoading(false);}})();},[]);return (0,jsx_runtime.jsxs)(View["default"],{style:ProfileComponent_styles.container,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),(0,jsx_runtime.jsx)(ScrollView["default"],{contentContainerStyle:ProfileComponent_styles.scrollViewContent,showsVerticalScrollIndicator:false,children:(0,jsx_runtime.jsxs)(View["default"],{style:ProfileComponent_styles.container,children:[(0,jsx_runtime.jsx)(Text["default"],{style:{color:Colors.dark.text,fontSize:20,paddingLeft:5,fontFamily:BOLD},children:"NFT"}),(0,jsx_runtime.jsx)(View["default"],{style:ProfileComponent_styles.listWrapper,children:userProfile&&userProfile.map(function(item,idx){return (0,jsx_runtime.jsx)(react.Fragment,{children:(0,jsx_runtime.jsx)(ItemCard,{handleListing:function handleListing(item){return _handleListing(item);},item:item})},idx);})})]})})]});};var windowHeight=Dimensions["default"].get('window').height;var scrollViewHeight=windowHeight-170;var ProfileComponent_styles=StyleSheet["default"].create({container:{display:'flex',flexDirection:'column',padding:12,width:'100%'},scrollViewContent:{height:scrollViewHeight},listWrapper:{display:'flex',flexDirection:'row',flexWrap:'wrap',justifyContent:'center',gap:20,alignItems:'center',flexGrow:1,width:'100%',paddingHorizontal:6,paddingVertical:12}});
;// CONCATENATED MODULE: ./src/screens/Profile.tsx
var Profile=function Profile(){return (0,jsx_runtime.jsxs)(Screen,{style:Profile_styles.container,children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsx)(ProfileComponent,{})]});};var Profile_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background}});
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/TextInput/index.js
var TextInput = __webpack_require__(3497);
;// CONCATENATED MODULE: ./src/screens/CheckBag.tsx
var CheckBag=function CheckBag(){var _useState=(0,react.useState)(''),_useState2=(0,slicedToArray["default"])(_useState,2),searchValue=_useState2[0],setSearchValue=_useState2[1];var _useState3=(0,react.useState)(null),_useState4=(0,slicedToArray["default"])(_useState3,2),data=_useState4[0],setData=_useState4[1];var _useContext=(0,react.useContext)(LoadingContext),loading=_useContext.loading,setLoading=_useContext.setLoading;var handleSearch=function(){var _ref=(0,asyncToGenerator["default"])(function*(){setLoading(true);try{var response=yield ShyftService.getProfile(searchValue);setData(response);}catch(e){console.log(e);}setLoading(false);});return function handleSearch(){return _ref.apply(this,arguments);};}();return (0,jsx_runtime.jsxs)(Screen,{style:CheckBag_styles.container,children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsxs)(View["default"],{style:CheckBag_styles.searchWrapper,children:[(0,jsx_runtime.jsx)(TextInput["default"],{style:CheckBag_styles.innerSearch,value:searchValue,onChangeText:setSearchValue,placeholder:"Wallet Address",placeholderTextColor:Colors.dark.greyText}),(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:CheckBag_styles.searchBtn,onPress:handleSearch,children:(0,jsx_runtime.jsx)(Text["default"],{style:CheckBag_styles.searchBtnText,children:"Search"})})]}),(0,jsx_runtime.jsx)(ScrollView["default"],{contentContainerStyle:CheckBag_styles.scrollViewContent,showsVerticalScrollIndicator:false,children:(0,jsx_runtime.jsxs)(View["default"],{style:CheckBag_styles.appWrapper,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),data&&data.map(function(item,idx){return (0,jsx_runtime.jsx)(react.Fragment,{children:(0,jsx_runtime.jsx)(ItemCard,{item:item})},idx);})]})})]});};var CheckBag_windowHeight=Dimensions["default"].get('window').height;var CheckBag_scrollViewHeight=CheckBag_windowHeight-150;var CheckBag_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background,display:'flex',flexDirection:'column',padding:10},searchWrapper:{flexDirection:'row',alignItems:'center',justifyContent:'center',minHeight:50,marginTop:10},scrollViewContent:{height:CheckBag_scrollViewHeight,paddingVertical:10},appWrapper:{flexDirection:'row',gap:20,flexWrap:'wrap',paddingHorizontal:20,marginTop:20},innerSearch:{color:Colors.dark.text,paddingHorizontal:10,flexGrow:1,height:'100%',borderWidth:1,borderColor:'#303030',marginRight:20},searchBtn:{backgroundColor:'white',paddingVertical:10,paddingHorizontal:20,borderRadius:5,flexDirection:'row',alignItems:'center',height:'100%'},searchBtnText:{color:'black',fontSize:16,fontWeight:'bold'}});
;// CONCATENATED MODULE: ./src/screens/Marketplace.tsx
var Marketplace=function Marketplace(){var _useState=(0,react.useState)(''),_useState2=(0,slicedToArray["default"])(_useState,2),searchValue=_useState2[0],setSearchValue=_useState2[1];var _useState3=(0,react.useState)(null),_useState4=(0,slicedToArray["default"])(_useState3,2),data=_useState4[0],setData=_useState4[1];var _useContext=(0,react.useContext)(LoadingContext),loading=_useContext.loading,setLoading=_useContext.setLoading;var navigation=(0,core_lib_module.useNavigation)();(0,react.useEffect)(function(){setLoading(true);(0,asyncToGenerator["default"])(function*(){var list=yield ShyftService.getActiveListings();setData(list.data);setLoading(false);})();},[]);var navigateToDetail=function navigateToDetail(item){navigation.navigate('NFT Detail',{item:item});};return (0,jsx_runtime.jsxs)(Screen,{style:Marketplace_styles.container,children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsx)(ScrollView["default"],{contentContainerStyle:Marketplace_styles.scrollViewContent,showsVerticalScrollIndicator:false,children:(0,jsx_runtime.jsxs)(View["default"],{style:Marketplace_styles.appWrapper,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),data&&data.map(function(item,idx){return (0,jsx_runtime.jsx)(TouchableOpacity["default"],{onPress:function onPress(){return navigateToDetail(item);},children:(0,jsx_runtime.jsx)(ItemCard,{item:item})},idx);})]})})]});};var Marketplace_windowHeight=Dimensions["default"].get('window').height;var Marketplace_scrollViewHeight=Marketplace_windowHeight-150;var Marketplace_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background,display:'flex',flexDirection:'column'},scrollViewContent:{height:Marketplace_scrollViewHeight,paddingVertical:10},appWrapper:{flexDirection:'row',gap:20,justifyContent:'center',flexWrap:'wrap',paddingHorizontal:20,marginTop:20},innerSearch:{color:Colors.dark.text,paddingHorizontal:10,flexGrow:1,height:'100%',borderWidth:1,borderColor:'#303030',marginRight:20},searchBtn:{backgroundColor:'white',paddingVertical:10,paddingHorizontal:20,borderRadius:5,flexDirection:'row',alignItems:'center',height:'100%'},searchBtnText:{color:'black',fontSize:16,fontWeight:'bold'}});
// EXTERNAL MODULE: ./node_modules/@wormhole-foundation/wormhole-connect/lib/esm/index.js + 8 modules
var lib_esm = __webpack_require__(6411);
;// CONCATENATED MODULE: ./src/screens/Transfer.tsx
var Transfer=function Transfer(){var _useContext=(0,react.useContext)(LoadingContext),loading=_useContext.loading,setLoading=_useContext.setLoading;(0,react.useEffect)(function(){setLoading(true);setTimeout(function(){setLoading(false);},500);},[]);return (0,jsx_runtime.jsxs)(Screen,{style:Transfer_styles.container,children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsxs)(ScrollView["default"],{contentContainerStyle:Transfer_styles.scrollViewContent,showsVerticalScrollIndicator:false,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),(0,jsx_runtime.jsx)(lib_esm["default"],{})]})]});};var Transfer_windowHeight=Dimensions["default"].get('window').height;var Transfer_scrollViewHeight=Transfer_windowHeight-150;var Transfer_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background,display:'flex',flexDirection:'column'},scrollViewContent:{height:Transfer_scrollViewHeight,paddingVertical:10}});
;// CONCATENATED MODULE: ./src/components/Deposit.tsx
function Deposit(_ref){var navigation=_ref.navigation;var _useContext=(0,react.useContext)(WalletContext),walletInfo=_useContext.wallet,refresh=_useContext.refresh;var _useWallet=(0,useWallet.useWallet)(),wallet=_useWallet.wallet;var _useContext2=(0,react.useContext)(LoadingContext),loading=_useContext2.loading,setLoading=_useContext2.setLoading;var _useState=(0,react.useState)(''),_useState2=(0,slicedToArray["default"])(_useState,2),amount=_useState2[0],setAmount=_useState2[1];var handleSend=function(){var _ref2=(0,asyncToGenerator["default"])(function*(){setLoading(true);var send=yield ShyftService.sendSol(walletInfo.address,amount);var sign=yield ShyftService.signContract(send.result.encoded_transaction,wallet.adapter);if(sign){var appBalance=yield lib_module["default"].getItem('appBalance');yield lib_module["default"].setItem('appBalance',(Number(appBalance)+Number(amount)).toString());yield refresh(0-Number(amount));}navigation.navigate('Home');setLoading(false);});return function handleSend(){return _ref2.apply(this,arguments);};}();return (0,jsx_runtime.jsxs)(View["default"],{style:Deposit_styles.wrapper,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),(0,jsx_runtime.jsx)(TextInput["default"],{style:Deposit_styles.input,value:amount,onChangeText:function onChangeText(e){return setAmount(e);},placeholder:"Amount",placeholderTextColor:Colors.dark.greyText}),(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Deposit_styles.sendBtn,loading&&Deposit_styles.disableBtn],disabled:loading,onPress:handleSend,children:(0,jsx_runtime.jsx)(Text["default"],{style:Deposit_styles.sendBtnText,children:"Deposit"})})]});}var Deposit_styles=StyleSheet["default"].create({wrapper:{flex:1,display:'flex',justifyContent:'center',alignItems:'center',gap:20,backgroundColor:Colors.dark.background},input:{color:Colors.dark.text,paddingHorizontal:10,paddingVertical:20,borderWidth:1,borderColor:'#303030',width:'50%'},sendBtn:{backgroundColor:'white',paddingVertical:10,paddingHorizontal:20,borderRadius:5,flexDirection:'row',alignItems:'center',justifyContent:'center',width:'50%'},sendBtnText:{color:'black',fontSize:16,fontWeight:'bold'},disableBtn:{opacity:0.2}});
;// CONCATENATED MODULE: ./src/components/Withdraw.tsx
function Withdraw(_ref){var navigation=_ref.navigation;var _useContext=(0,react.useContext)(WalletContext),wallet=_useContext.wallet,refresh=_useContext.refresh;var _useContext2=(0,react.useContext)(LoadingContext),loading=_useContext2.loading,setLoading=_useContext2.setLoading;var _useState=(0,react.useState)(''),_useState2=(0,slicedToArray["default"])(_useState,2),amount=_useState2[0],setAmount=_useState2[1];var handleSend=function(){var _ref2=(0,asyncToGenerator["default"])(function*(){setLoading(true);var send=yield ShyftService.withdraw(wallet.address,amount);var sign=yield ShyftService.signWithPrivate(send.result.encoded_transaction);if(sign){var appBalance=yield lib_module["default"].getItem('appBalance');yield lib_module["default"].setItem('appBalance',(Number(appBalance)-Number(amount)).toString());yield refresh(0);}navigation.navigate('Home');setLoading(false);});return function handleSend(){return _ref2.apply(this,arguments);};}();return (0,jsx_runtime.jsxs)(View["default"],{style:Withdraw_styles.wrapper,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),(0,jsx_runtime.jsx)(TextInput["default"],{style:Withdraw_styles.input,value:amount,onChangeText:function onChangeText(e){return setAmount(e);},placeholder:"Amount",placeholderTextColor:Colors.dark.greyText}),(0,jsx_runtime.jsx)(TouchableOpacity["default"],{style:[Withdraw_styles.sendBtn,loading&&Withdraw_styles.disableBtn],disabled:loading,onPress:handleSend,children:(0,jsx_runtime.jsx)(Text["default"],{style:Withdraw_styles.sendBtnText,children:"Withdraw"})})]});}var Withdraw_styles=StyleSheet["default"].create({wrapper:{flex:1,display:'flex',justifyContent:'center',alignItems:'center',gap:20,backgroundColor:Colors.dark.background},input:{color:Colors.dark.text,paddingHorizontal:10,paddingVertical:20,borderWidth:1,borderColor:'#303030',width:'50%'},sendBtn:{backgroundColor:'white',paddingVertical:10,paddingHorizontal:20,borderRadius:5,flexDirection:'row',alignItems:'center',justifyContent:'center',width:'50%'},sendBtnText:{color:'black',fontSize:16,fontWeight:'bold'},disableBtn:{opacity:0.2}});
;// CONCATENATED MODULE: ./src/screens/DepositWithdraw.tsx
var Tab=(0,createBottomTabNavigator["default"])();var DepositWithdraw=function DepositWithdraw(){var _useContext=(0,react.useContext)(LoadingContext),loading=_useContext.loading,setLoading=_useContext.setLoading;var tabBarIcon=function tabBarIcon(_ref){var color=_ref.color,size=_ref.size;return (0,jsx_runtime.jsx)(MaterialCommunityIcons["default"],{name:"currency-usd",color:color,size:size});};var withDrawIcon=function withDrawIcon(_ref2){var color=_ref2.color,size=_ref2.size;return (0,jsx_runtime.jsx)(MaterialCommunityIcons["default"],{name:"currency-usd-off",color:color,size:size});};return (0,jsx_runtime.jsxs)(Screen,{style:DepositWithdraw_styles.container,children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsxs)(Tab.Navigator,{initialRouteName:"Deposit",screenOptions:{tabBarActiveTintColor:'#A79EE5',tabBarActiveBackgroundColor:Colors.dark.inputBackground,tabBarInactiveBackgroundColor:Colors.dark.inputBackground,tabBarStyle:DepositWithdraw_styles.tabBarStyle},children:[(0,jsx_runtime.jsx)(Tab.Screen,{name:"Deposit",component:Deposit,options:{tabBarIcon:tabBarIcon,headerStyle:{height:0},headerTitle:''}}),(0,jsx_runtime.jsx)(Tab.Screen,{name:"Withdraw",component:Withdraw,options:{tabBarIcon:withDrawIcon,headerStyle:{height:0},headerTitle:''}})]})]});};var DepositWithdraw_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background,display:'flex',flexDirection:'column'},headerStyle:{backgroundColor:Colors.dark.inputBackground,borderBottomColor:'#303030',maxHeight:55},tabBarStyle:{borderTopColor:Colors.dark.background,borderTopWidth:0}});
// EXTERNAL MODULE: ./node_modules/react-native-web/dist/exports/Animated/index.js + 51 modules
var Animated = __webpack_require__(9092);
;// CONCATENATED MODULE: ./src/assets/dice/dice1.png
const dice1_namespaceObject = __webpack_require__.p + "static/media/dice1.4214d536ff3424bf77f7.png";
;// CONCATENATED MODULE: ./src/assets/dice/dice2.png
const dice2_namespaceObject = __webpack_require__.p + "static/media/dice2.c3a4c8c00cb9df1e9f98.png";
;// CONCATENATED MODULE: ./src/assets/dice/dice3.png
const dice3_namespaceObject = __webpack_require__.p + "static/media/dice3.d5810f55940b1f991d70.png";
;// CONCATENATED MODULE: ./src/assets/dice/dice4.png
const dice4_namespaceObject = __webpack_require__.p + "static/media/dice4.2a8a8116cfa8b6cc0d23.png";
;// CONCATENATED MODULE: ./src/assets/dice/dice5.png
const dice5_namespaceObject = __webpack_require__.p + "static/media/dice5.c446764499a4a30dfe8b.png";
;// CONCATENATED MODULE: ./src/assets/dice/dice6.png
const dice6_namespaceObject = __webpack_require__.p + "static/media/dice6.89fe5f53c0b6ec072ba7.png";
;// CONCATENATED MODULE: ./src/assets/avatar/ban.jpg
const ban_namespaceObject = __webpack_require__.p + "static/media/ban.e04d9df4d1073ff649ec.jpg";
;// CONCATENATED MODULE: ./src/assets/avatar/nguoikhac.jpg
const nguoikhac_namespaceObject = __webpack_require__.p + "static/media/nguoikhac.1eb9a6327c51f3aae9fe.jpg";
;// CONCATENATED MODULE: ./src/components/Games/MyGame.tsx
function MyGame_ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);enumerableOnly&&(symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;})),keys.push.apply(keys,symbols);}return keys;}function MyGame_objectSpread(target){for(var i=1;i<arguments.length;i++){var source=null!=arguments[i]?arguments[i]:{};i%2?MyGame_ownKeys(Object(source),!0).forEach(function(key){(0,defineProperty["default"])(target,key,source[key]);}):Object.getOwnPropertyDescriptors?Object.defineProperties(target,Object.getOwnPropertyDescriptors(source)):MyGame_ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}return target;}function MyGame(){var _useState=(0,react.useState)(null),_useState2=(0,slicedToArray["default"])(_useState,2),player1Number=_useState2[0],setPlayer1Number=_useState2[1];var _useState3=(0,react.useState)(null),_useState4=(0,slicedToArray["default"])(_useState3,2),player2Number=_useState4[0],setPlayer2Number=_useState4[1];var _useState5=(0,react.useState)(false),_useState6=(0,slicedToArray["default"])(_useState5,2),isLoading=_useState6[0],setIsLoading=_useState6[1];var _useState7=(0,react.useState)(false),_useState8=(0,slicedToArray["default"])(_useState7,2),isButtonDisabled=_useState8[0],setIsButtonDisabled=_useState8[1];var randomImages=[dice1_namespaceObject,dice2_namespaceObject,dice3_namespaceObject,dice4_namespaceObject,dice5_namespaceObject,dice6_namespaceObject];var _useState9=(0,react.useState)(randomImages[0]),_useState10=(0,slicedToArray["default"])(_useState9,2),image1=_useState10[0],setImage1=_useState10[1];var _useState11=(0,react.useState)(randomImages[1]),_useState12=(0,slicedToArray["default"])(_useState11,2),image2=_useState12[0],setImage2=_useState12[1];var _useState13=(0,react.useState)(''),_useState14=(0,slicedToArray["default"])(_useState13,2),number=_useState14[0],setNumber=_useState14[1];var _useState15=(0,react.useState)(new Animated["default"].Value(0)),_useState16=(0,slicedToArray["default"])(_useState15,1),diceAnimation=_useState16[0];var _useState17=(0,react.useState)(''),_useState18=(0,slicedToArray["default"])(_useState17,2),myChoose=_useState18[0],setMyChoose=_useState18[1];var _useState19=(0,react.useState)(false),_useState20=(0,slicedToArray["default"])(_useState19,2),winner=_useState20[0],setWinner=_useState20[1];var _useContext=(0,react.useContext)(WalletContext),setWallet=_useContext.setWallet;var generateRandomNumber=function generateRandomNumber(choose){setMyChoose(choose);setIsLoading(true);setIsButtonDisabled(true);setPlayer1Number(null);setPlayer2Number(null);setTimeout(function(){var player1=Math.floor(Math.random()*6)+1;var player2=Math.floor(Math.random()*6)+1;setPlayer1Number(player1);setPlayer2Number(player2);setImage1(randomImages[player1-1]);setImage2(randomImages[player2-1]);setIsLoading(false);setIsButtonDisabled(false);if(player1>player2){setWinner('player');}else if(player1<player2){setWinner('banker');}handleWallet(choose===winner);},2000);};var determineWinner=function determineWinner(){if(player1Number===null||player2Number===null){return'';}var winner='';if(player1Number>player2Number){winner='player';}else if(player1Number<player2Number){winner='banker';}switch(winner){case'player':return'Player win!';break;case'banker':return'Banker win!';break;default:return'Tie!';}};var handleWallet=function(){var _ref=(0,asyncToGenerator["default"])(function*(type){var currentBalance=yield lib_module["default"].getItem('appBalance');var newBalance=0;if(type){newBalance=Number(currentBalance)+0.1;}else{newBalance=Number(currentBalance)-0.1;}yield lib_module["default"].setItem('appBalance',JSON.stringify(newBalance));setWallet(function(prev){return MyGame_objectSpread(MyGame_objectSpread({},prev),{},{appBalance:newBalance.toFixed(2)});});});return function handleWallet(_x){return _ref.apply(this,arguments);};}();var styles=StyleSheet["default"].create({container:{flex:1,flexDirection:'row',position:'relative'},leftHalf:{flex:1,backgroundColor:'white',alignItems:'center',justifyContent:'center'},rightHalf:{flex:1,backgroundColor:'pink',alignItems:'center',justifyContent:'center'},playerContainer:{alignItems:'center',marginBottom:20},playerImageU:{width:150,height:150,borderRadius:75,marginBottom:'0px'},playerName:{fontFamily:'Futura-Medium',fontSize:20,fontWeight:'bold',marginTop:10},diceImage:{marginTop:10,width:100,height:100},resultContainer:{alignItems:'center',position:'absolute',zIndex:9999,left:'50%',top:'50%',transform:[{translateX:-50},{translateY:25}],padding:10,borderRadius:10,backgroundColor:'#ccc'},resultText:{fontSize:30,color:'white',textAlign:'center'},loading:{transform:[{translateX:-25},{translateY:25}]},hasResult:{transform:[{translateX:-75}]},buttonContainer:{marginRight:700,marginTop:20,alignSelf:'center'},diceContainer:{marginTop:15,alignItems:'center'},playerImageCompu:{width:150,height:150,borderRadius:75}});return (0,jsx_runtime.jsxs)(jsx_runtime.Fragment,{children:[(0,jsx_runtime.jsx)(Balance,{}),(0,jsx_runtime.jsxs)(View["default"],{style:styles.container,children:[(0,jsx_runtime.jsx)(View["default"],{style:[styles.resultContainer,isLoading&&styles.loading,winner&&styles.hasResult],children:isLoading?(0,jsx_runtime.jsx)(ActivityIndicator["default"],{size:"large",color:"black"}):(0,jsx_runtime.jsxs)(Text["default"],{style:styles.resultText,children:["Result: ",(0,jsx_runtime.jsx)("br",{}),determineWinner()]})}),(0,jsx_runtime.jsx)(View["default"],{style:styles.leftHalf,children:(0,jsx_runtime.jsxs)(View["default"],{style:[styles.playerContainer],children:[(0,jsx_runtime.jsx)(Image["default"],{style:styles.playerImageU,source:ban_namespaceObject}),(0,jsx_runtime.jsx)(Text["default"],{style:styles.playerName,children:"Player"}),(0,jsx_runtime.jsx)(Animated["default"].Image,{style:styles.diceImage,source:image1}),(0,jsx_runtime.jsxs)(Text["default"],{style:styles.playerName,children:["Score: ",player1Number]})]})}),(0,jsx_runtime.jsx)(View["default"],{style:styles.rightHalf,children:(0,jsx_runtime.jsxs)(View["default"],{style:[styles.playerContainer],children:[(0,jsx_runtime.jsx)(Image["default"],{style:styles.playerImageCompu,source:nguoikhac_namespaceObject}),(0,jsx_runtime.jsx)(Text["default"],{style:styles.playerName,children:"Banker"}),(0,jsx_runtime.jsxs)(View["default"],{style:styles.diceContainer,children:[(0,jsx_runtime.jsx)(Image["default"],{style:styles.diceImage,source:image2}),(0,jsx_runtime.jsxs)(Text["default"],{style:styles.playerName,children:["Score: ",player2Number]})]})]})}),(0,jsx_runtime.jsxs)(View["default"],{style:{position:'absolute',left:'45.5%',top:'70%'},children:[(0,jsx_runtime.jsx)(View["default"],{style:[styles.buttonContainer,{borderRadius:12,overflow:'hidden'}],children:(0,jsx_runtime.jsx)(Button["default"],{title:"Banker",onPress:function onPress(){return generateRandomNumber('banker');},disabled:isButtonDisabled})}),(0,jsx_runtime.jsx)(View["default"],{style:styles.buttonContainer,children:(0,jsx_runtime.jsx)(Button["default"],{title:"0.1 SOL",disabled:true})}),(0,jsx_runtime.jsx)(View["default"],{style:[styles.buttonContainer,{borderRadius:12,overflow:'hidden'}],children:(0,jsx_runtime.jsx)(Button["default"],{title:"Player",onPress:function onPress(){return generateRandomNumber('player');},disabled:isButtonDisabled})})]})]})]});}
// EXTERNAL MODULE: ./node_modules/@solana/wallet-adapter-react-ui/lib/esm/WalletMultiButton.js + 3 modules
var WalletMultiButton = __webpack_require__(8919);
;// CONCATENATED MODULE: ./src/components/Header/HeaderRight.tsx
function HeaderRight_ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);enumerableOnly&&(symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;})),keys.push.apply(keys,symbols);}return keys;}function HeaderRight_objectSpread(target){for(var i=1;i<arguments.length;i++){var source=null!=arguments[i]?arguments[i]:{};i%2?HeaderRight_ownKeys(Object(source),!0).forEach(function(key){(0,defineProperty["default"])(target,key,source[key]);}):Object.getOwnPropertyDescriptors?Object.defineProperties(target,Object.getOwnPropertyDescriptors(source)):HeaderRight_ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}return target;}__webpack_require__(4789);var HeaderRight=function HeaderRight(){var _useWallet=(0,useWallet.useWallet)(),publicKey=_useWallet.publicKey;var _useContext=(0,react.useContext)(WalletContext),wallet=_useContext.wallet,setWallet=_useContext.setWallet;(0,react.useEffect)(function(){(0,asyncToGenerator["default"])(function*(){if(publicKey&&!wallet){var appBalance=yield lib_module["default"].getItem('appBalance');yield setWallet(function(prev){return HeaderRight_objectSpread(HeaderRight_objectSpread({},prev),{},{address:publicKey,balance:12,appBalance:Number(appBalance).toFixed(2)});});}else if(wallet&&publicKey===null&&wallet.address){setWallet(null);}})();},[publicKey]);return (0,jsx_runtime.jsx)("div",{style:{marginRight:10},children:(0,jsx_runtime.jsx)(WalletMultiButton.WalletMultiButton,{})});};
;// CONCATENATED MODULE: ./src/screens/NFTDetails.tsx
var NFTDetail=function NFTDetail(_ref){var route=_ref.route;var item=route.params.item;var nft=item.nft;var _useContext=(0,react.useContext)(WalletContext),walletInfo=_useContext.wallet;var _useWallet=(0,useWallet.useWallet)(),wallet=_useWallet.wallet;var _useContext2=(0,react.useContext)(LoadingContext),loading=_useContext2.loading,setLoading=_useContext2.setLoading;var handleBuy=function(){var _ref2=(0,asyncToGenerator["default"])(function*(){setLoading(true);try{var dataBuy={nftAddress:item.nft_address,sellerWallet:item.seller_address,price:item.price,buyerWallet:walletInfo.address};var buyRes=yield ShyftService.buyNFT(dataBuy);if(buyRes.encoded_transaction){yield ShyftService.signContract(buyRes.encoded_transaction,wallet.adapter);}}catch(e){console.log(e);}finally{setLoading(false);}});return function handleBuy(){return _ref2.apply(this,arguments);};}();return (0,jsx_runtime.jsxs)(View["default"],{style:NFTDetails_styles.container,children:[loading&&(0,jsx_runtime.jsx)(FullScreenLoadingIndicator,{}),(0,jsx_runtime.jsxs)(View["default"],{style:NFTDetails_styles.item,children:[(0,jsx_runtime.jsx)(Image["default"],{source:nft.image_uri,style:NFTDetails_styles.image}),(0,jsx_runtime.jsxs)(View["default"],{style:NFTDetails_styles.itemInfo,children:[(0,jsx_runtime.jsx)(Text["default"],{style:{color:'white',fontSize:32,fontFamily:BOLD},children:nft.name}),(0,jsx_runtime.jsxs)(Text["default"],{style:{color:'white',fontSize:16,fontFamily:MEDIUM},children:["Decription: ",nft==null?void 0:nft.description]}),(0,jsx_runtime.jsxs)(Text["default"],{style:{color:'white',fontSize:20,fontFamily:MEDIUM},children:[item==null?void 0:item.price,(0,jsx_runtime.jsx)(Text["default"],{style:{color:'#9548FC',fontSize:20,fontFamily:MEDIUM,marginLeft:4},children:item==null?void 0:item.currency_symbol})]}),(0,jsx_runtime.jsx)(Button["default"],{onPress:handleBuy,title:"Buy"})]})]})]});};var NFTDetails_windowHeight=Dimensions["default"].get('window').height;var NFTDetails_scrollViewHeight=NFTDetails_windowHeight-150;var NFTDetails_styles=StyleSheet["default"].create({container:{backgroundColor:Colors.dark.background,display:'flex',flexDirection:'column',minHeight:'100vh',maxWidth:'100vw',padding:20},item:{display:'flex',flexDirection:'row',height:'60%',gap:20},itemInfo:{display:'flex',flexDirection:'column',gap:10,width:'35%'},image:{width:'60%',height:'100%',borderRadius:12}});/* harmony default export */ const NFTDetails = (NFTDetail);
;// CONCATENATED MODULE: ./src/App.tsx
__webpack_require__.g.Buffer=__webpack_require__.g.Buffer||buffer.Buffer;var App_Tab=(0,createBottomTabNavigator["default"])();var Stack=(0,createStackNavigator["default"])();function TabNavigator(){var _useContext=(0,react.useContext)(WalletContext),wallet=_useContext.wallet;var tabBarIcon=function tabBarIcon(_ref){var color=_ref.color,size=_ref.size;return (0,jsx_runtime.jsx)(MaterialCommunityIcons["default"],{name:"widgets-outline",color:color,size:size});};var ProfileBarIcon=function ProfileBarIcon(_ref2){var color=_ref2.color,size=_ref2.size;return (0,jsx_runtime.jsx)(MaterialIcons["default"],{name:"person-outline",color:color,size:size});};return (0,jsx_runtime.jsxs)(App_Tab.Navigator,{initialRouteName:"App",screenOptions:{tabBarActiveTintColor:'#A79EE5',tabBarActiveBackgroundColor:Colors.dark.inputBackground,tabBarInactiveBackgroundColor:Colors.dark.inputBackground,tabBarStyle:App_styles.tabBarStyle,tabBarLabelStyle:{paddingBottom:4}},children:[(0,jsx_runtime.jsx)(App_Tab.Screen,{name:"App",component:AppMenu,options:{tabBarIcon:tabBarIcon,headerStyle:App_styles.headerStyle,headerLeft:function headerLeft(){return (0,jsx_runtime.jsx)(HeaderLeft,{title:"Home"});},headerRight:function headerRight(){return (0,jsx_runtime.jsx)(HeaderRight,{});},headerTitle:''}}),(wallet==null?void 0:wallet.address)&&(0,jsx_runtime.jsx)(App_Tab.Screen,{name:"Profile",component:Profile,options:{tabBarIcon:ProfileBarIcon,tabBarLabel:'Profile',headerStyle:App_styles.headerStyle,headerLeft:function headerLeft(){return (0,jsx_runtime.jsx)(HeaderLeft,{title:"Profile"});},headerRight:function headerRight(){return (0,jsx_runtime.jsx)(HeaderRight,{});},headerTitle:''}})]});}function App_App(){var _useFonts=(0,dev.useFonts)({'DMSans-Bold':__webpack_require__(9522),'DMSans-Medium':__webpack_require__(2915),'DMSans-Regular':__webpack_require__(1779)}),_useFonts2=(0,slicedToArray["default"])(_useFonts,1),fontsLoaded=_useFonts2[0];if(!fontsLoaded){return (0,jsx_runtime.jsx)(View["default"],{style:{flex:1,alignItems:'center',justifyContent:'center'},children:(0,jsx_runtime.jsx)(ActivityIndicator["default"],{})});}return (0,jsx_runtime.jsx)(es.RecoilRoot,{children:(0,jsx_runtime.jsx)(ProviderWrapper,{children:(0,jsx_runtime.jsx)(NavigationContainer["default"],{children:(0,jsx_runtime.jsxs)(Stack.Navigator,{children:[(0,jsx_runtime.jsx)(Stack.Screen,{name:"Home",component:TabNavigator,options:{headerShown:false}}),(0,jsx_runtime.jsx)(Stack.Screen,{name:"Search",component:CheckBag,options:{headerStyle:App_styles.headerStyle,headerTintColor:Colors.dark.text}}),(0,jsx_runtime.jsx)(Stack.Screen,{name:"Marketplace",component:Marketplace,options:{headerStyle:App_styles.headerStyle,headerTintColor:Colors.dark.text}}),(0,jsx_runtime.jsx)(Stack.Screen,{name:"NFT Detail",component:NFTDetails,options:{headerStyle:App_styles.headerStyle,headerTintColor:Colors.dark.text}}),(0,jsx_runtime.jsx)(Stack.Screen,{name:"Transfer",component:Transfer,options:{headerStyle:App_styles.headerStyle,headerTintColor:Colors.dark.text}}),(0,jsx_runtime.jsx)(Stack.Screen,{name:"Deposit Withdraw",component:DepositWithdraw,options:{headerStyle:App_styles.headerStyle,headerTintColor:Colors.dark.text}}),(0,jsx_runtime.jsx)(Stack.Screen,{name:"Lucky Game",component:MyGame,options:{headerStyle:App_styles.headerStyle,headerTintColor:Colors.dark.text}})]})})})});}var App_styles={headerStyle:{backgroundColor:Colors.dark.inputBackground,borderBottomColor:'#303030',maxHeight:55},tabBarStyle:{borderTopColor:Colors.dark.background,borderTopWidth:0}};/* harmony default export */ const src_App = ((0,registerRootComponent["default"])(App_App));

/***/ }),

/***/ 9522:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "static/media/DMSans-Bold.ac1dbf2cab9c0c270043.ttf";

/***/ }),

/***/ 2915:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "static/media/DMSans-Medium.db7d8d3b100f4ddbfe7e.ttf";

/***/ }),

/***/ 1779:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "static/media/DMSans-Regular.5d56aeb9225a4059996e.ttf";

/***/ }),

/***/ 363:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "static/media/sol-logo.68d113d5dfae0c530188.png";

/***/ }),

/***/ 6601:
/***/ (() => {

/* (ignored) */

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "./";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			179: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkweb"] = self["webpackChunkweb"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [548], () => (__webpack_require__(327)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=main.165162ab.js.map